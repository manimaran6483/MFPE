package com.consumer.feign;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "auth-client", url = "http://localhost:8081/auth")
public interface AuthClient {
    @GetMapping("/validate")
    public boolean validate(String token);
}
