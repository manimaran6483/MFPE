package com.consumer.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.consumer.feign.AuthClient;
import com.consumer.repository.BusinessRepository;
import com.consumer.repository.ConsumerRepository;
import com.consumer.request.ConsumerBusinessRequest;
import com.consumer.response.ConsumerBusiness;
import com.consumer.service.ConsumerService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ConsumerController {

	@Autowired
	ConsumerService consumerService;
	
	@Autowired
	AuthClient auth;
	
	@Autowired
	ConsumerRepository consumerRepo;
	
	@Autowired
	BusinessRepository businessRepo;
	
	@PostMapping("/createConsumerBusiness")
	public String createConsumerBusiness(@RequestHeader(name="Authorization")String token,
			@RequestBody ConsumerBusinessRequest consumerBusiness) throws Exception {
		if(auth.validate(token)) {
			log.info("Start CreateConsumerBusiness");
			if(!consumerService.checkBusinessEligibility(consumerBusiness)) {
				return "Sorry! You are not Eligible for Insurance";
			}
			String message = consumerService.createConsumerBusiness(consumerBusiness);
			log.info("End CreateConsumerBusiness");
			return message;
		}
		return "Invalid token! Login First";
	}
	
	@PostMapping("/updateConsumerBusiness")
	public String updateConsumerBusiness(@RequestHeader(name="Authorization") String token,
			@RequestBody ConsumerBusiness consumerBusiness) {
		if(auth.validate(token)) {
			log.info("Start updateConsumerBusiness");
			if(!consumerRepo.existsById(consumerBusiness.getConsumerId())) {
				return "Sorry! No Consumer Found";
			}
			if(!businessRepo.existsById(consumerBusiness.getBusinessid())) {
				return "Sorry! No Business Found";
			}
			String message = consumerService.updateConsumerBusiness(consumerBusiness);
			log.info("End updateConsumerBusiness");
			return message;
		}
		
		return "Invalid Token! Login again";
	}
	
	@GetMapping("/viewConsumerBusiness")
	public ResponseEntity<?> viewConsumerBusiness(@RequestHeader(name="Authorization")String token,
	@RequestParam long id) {
		if(auth.validate(token)) {
			log.info("Start viewConsumerBusiness");
			if(!consumerRepo.existsById(id)) {
				return ResponseEntity.badRequest().body("Sorry! No Consumer Found");
			}
			ConsumerBusiness c = consumerService.viewConsumerBusiness(id);
			log.info("End view ConsumerBusiness");
			return ResponseEntity.ok(c);
		}
		
		return ResponseEntity.badRequest().body("Invalid Token");
	}
}
