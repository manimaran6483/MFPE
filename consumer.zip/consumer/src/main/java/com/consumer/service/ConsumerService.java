package com.consumer.service;

import com.consumer.model.Business;
import com.consumer.model.Consumer;
import com.consumer.model.Property;
import com.consumer.request.ConsumerBusinessRequest;
import com.consumer.response.BusinessProperty;
import com.consumer.response.ConsumerBusiness;


public interface ConsumerService {

	String createConsumerBusiness(ConsumerBusinessRequest consumerBusinessRequest);

	Long calBusinessValue(Long businessturnover, Long capitalinvested);

	Long calPropertyValue(Long costoftheasset, Long salvagevalue, Long usefullifeoftheAsset);

	String updateConsumerBusiness(ConsumerBusiness consumerBusinessDetails);

	ConsumerBusiness viewConsumerBusiness(Long consumerid);

	String createBusinessProperty(ConsumerBusinessRequest businessPropertyRequest);

	String updateBusinessProperty(BusinessProperty businessPropertyDetails);

	Property viewConsumerProperty(Long consumerid, Long propertyid);

	Boolean checkBusinessEligibility(ConsumerBusinessRequest consumerBusinessRequest) throws Exception;

	Boolean checkPropertyEligibility(String propertytype, String insurancetype, String buildingtype, Long buildingage)
			throws Exception;

}
