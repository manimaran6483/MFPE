package com.consumer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.consumer.model.Consumer;
import com.consumer.model.Property;
import com.consumer.repository.BusinessRepository;
import com.consumer.repository.ConsumerRepository;
import com.consumer.repository.PropertyRepository;
import com.consumer.request.ConsumerBusinessRequest;
import com.consumer.response.BusinessProperty;
import com.consumer.response.ConsumerBusiness;
@Service
public class ConsumerServiceImpl implements ConsumerService {

	@Autowired
	ConsumerRepository consumerRepo;
	
	@Autowired
	PropertyRepository propertyRepo;
	
	@Autowired
	BusinessRepository businessRepo;

	@Override
	public String createConsumerBusiness(ConsumerBusinessRequest consumerBusinessRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long calBusinessValue(Long businessturnover, Long capitalinvested) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long calPropertyValue(Long costoftheasset, Long salvagevalue, Long usefullifeoftheAsset) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateConsumerBusiness(ConsumerBusiness consumerBusinessDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConsumerBusiness viewConsumerBusiness(Long consumerid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createBusinessProperty(ConsumerBusinessRequest businessPropertyRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateBusinessProperty(BusinessProperty businessPropertyDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Property viewConsumerProperty(Long consumerid, Long propertyid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean checkBusinessEligibility(ConsumerBusinessRequest consumerBusinessRequest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean checkPropertyEligibility(String propertytype, String insurancetype, String buildingtype,
			Long buildingage) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
